#!/bin/bash
# Compiles every C program into ./build/  (e.g. build/exp4_fcfs)
# Usage: ./build.sh
mkdir -p build
for f in exp*/*.c beyond_syllabus/*.c; do
    name=$(echo "${f%.c}" | tr '/' '_')
    if gcc -o "build/$name" "$f" -pthread; then
        echo "built  build/$name"
    else
        echo "FAILED $f"
    fi
done
