# CS5302 – Operating Systems Laboratory

Programs from the OS lab manual, one folder per experiment (`exp1` … `exp15`).
Written for Kali Linux (any Linux with `gcc` and `bash` works).

## Experiments

| Folder | Experiment | Files |
|--------|------------|-------|
| `exp1`  | Installation of Windows OS | `windows_commands.bat` (run on Windows) |
| `exp2`  | UNIX commands & shell programming | `kali_verify.sh`, `unix_commands.txt`, 8 shell scripts |
| `exp3`  | System calls: fork, exit, getpid, wait, close | `process`, `wait`, `close` (.c / .sh) |
| `exp4`  | CPU scheduling | `fcfs`, `sjf`, `priority`, `rr` (.c / .sh) |
| `exp5`  | Inter-process communication (pipe) | `pipe.c`, `pipe.sh`, `pipe_alt.sh` |
| `exp6`  | Semaphore implementation | `semaphore.c`, `semaphore.sh` |
| `exp7`  | Banker's algorithm | `bankers.c`, `bankers.sh` |
| `exp8`  | Deadlock detection | `deadlock.c`, `deadlock.sh` |
| `exp9`  | Threading (pthreads) | `thread.c`, `thread.sh` |
| `exp10` | Paging technique | `paging.c`, `paging.sh` |
| `exp11` | Memory allocation (first / best / worst fit) | `firstfit`, `bestfit`, `worstfit` (.c / .sh) |
| `exp12` | Page replacement (FIFO / LRU / Optimal) | `fifo`, `lru`, `optimal` (.c / .sh) |
| `exp13` | File organization | `sequential`, `direct`, `indexed` (.c / .sh) |
| `exp14` | File allocation | `seq_alloc`, `indexed_alloc`, `linked_alloc` (.c / .sh) |
| `exp15` | Disk scheduling | `fcfs`, `sstf`, `scan`, `cscan` (.c / .sh) |
| `beyond_syllabus` | Content beyond the syllabus (reference programs) | 5 C programs |

## Running

```bash
# C program
gcc exp4/fcfs.c -o fcfs
./fcfs

# programs using threads / semaphores need -pthread
gcc exp9/thread.c -o thread -pthread
./thread

# shell script
chmod +x exp2/factorial.sh
./exp2/factorial.sh

# compile every C program at once (output goes to build/)
./build.sh
```

## Notes

- `exp12/optimal.c` differs from the printed manual: the manual's version always
  replaced the first frame and over-counted page faults. This one gives the
  correct result (7 faults for the sample string with 3 frames).
- Some shell scripts in the manual (for example `exp11/*.sh`, `exp12/*.sh`,
  `exp15/sstf.sh`, `scan`, `cscan`) only print a demonstration message rather
  than running the full algorithm. They are included exactly as printed.
